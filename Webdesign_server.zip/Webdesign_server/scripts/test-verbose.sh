jest server --config=./config/jest.config.js --verbose
