process.env.DATABASE_URL = process.env.DATABASE_URL || 'mongodb+srv://karthiksai:Ragnar2302@cluster0.lrlhv.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';
process.env.NODE_ENV = process.env.NODE_ENV || 'development';
process.env.PORT = process.env.PORT || 3000;
process.env.ORIGIN = process.env.ORIGIN || 'http://localhost:8080';
process.env.DOMAIN = process.env.DOMAIN || 'localhost';
process.env.SESSION_SECRET = process.env.SESSION_SECRET || 'mern';
